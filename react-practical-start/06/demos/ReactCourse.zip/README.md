Before attempting to run this please first run the command "npm install".

Have fun,

Roland